import"./core-DxBnVPgq.js";function o(){return window.__TAURI_OS_PLUGIN_INTERNALS__.platform}export{o as platform};
